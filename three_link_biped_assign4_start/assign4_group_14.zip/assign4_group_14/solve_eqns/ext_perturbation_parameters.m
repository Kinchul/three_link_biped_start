function [step_number, value] = ext_perturbation_parameters()

global perturbation_value

step_number = 20;
value = perturbation_value;

end