close all
clear all
clc

set_path;

simulation